PV = 12000 #principal amount
PMT = 0 #monthly interest
interest_rate = 12.5 #interest rate
n = 12 #number of months

PV =  PMT/interest_rate(1-(1/(1+interest_rate)**n))